from .splitter import splitter as splitter
__all__ = ['splitter']
