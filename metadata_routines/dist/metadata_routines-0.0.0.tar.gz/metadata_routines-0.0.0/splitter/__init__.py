from .splitter import splitter as splitter
